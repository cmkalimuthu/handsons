package adapterPattern;

public interface Movable {

	double getSpeed();
	double getPrice();
}
