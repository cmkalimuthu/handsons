package adapterPattern;

public class Bugativeron implements Movable{
	 
	public double getSpeed() {
		return 268;
		
	}

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return 30;
	}

}
