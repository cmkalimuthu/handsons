package BuilderPattern;

public class Coke extends CoolDrinks{

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "coke";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 30.0f;
	}

}
