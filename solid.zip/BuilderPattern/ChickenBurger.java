package BuilderPattern;

public class ChickenBurger extends Burger{

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Non-Veg Burger";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 50.5f;
	}

}
